package com.portalosmanli.oyun;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Portal Osmanlı — oyunu (assets/index.html) tam ekran WebView içinde çalıştırır.
 * Oyun JavaScript'i "AndroidBridge" nesnesiyle AdMob ve Google Play Faturalandırma'ya ulaşır.
 *
 * NOT: Bu kod gerçek bir cihazda henüz test edilmedi. Reklam kimlikleri Google'ın TEST kimlikleridir.
 */
public class MainActivity extends Activity implements PurchasesUpdatedListener {

    // Play Console > Uygulama içi ürünler bölümünde AYNI kimliklerle ürün açılmalı.
    private static final List<String> CONSUMABLE = Arrays.asList("kese", "sandik", "hazine", "sezon");
    private static final List<String> PERMANENT = Arrays.asList("reklamsiz", "baslangic");

    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView web;
    private FrameLayout bannerBox;
    private AdView banner;
    private boolean bannerWanted = false;
    private RewardedAd rewarded;
    private boolean rewardedLoading = false;
    private boolean rewardEarned = false;
    private boolean pageReady = false;

    private BillingClient billing;
    private final Map<String, ProductDetails> products = new HashMap<>();

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);          // oyun kaydı (localStorage) için gerekli
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setTextZoom(100);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                pushPrices();
                checkOwned();
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bannerBox = new FrameLayout(this);
        bannerBox.setBackgroundColor(Color.BLACK);
        bannerBox.setVisibility(View.GONE);
        root.addView(bannerBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        hideSystemBars();

        web.loadUrl("file:///android_asset/index.html");

        MobileAds.initialize(this, status -> loadRewarded());
        setupBilling();
    }

    // ---------------- Tam ekran ----------------
    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    protected void onPause() {
        if (banner != null) banner.pause();
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (banner != null) banner.resume();
        if (billing != null && billing.isReady()) checkOwned();
    }

    @Override
    protected void onDestroy() {
        if (banner != null) banner.destroy();
        if (billing != null) billing.endConnection();
        web.destroy();
        super.onDestroy();
    }

    // Geri tuşu: oyun karar verir (pencere kapat / duraklat). "exit" dönerse uygulamadan çıkılır.
    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (!pageReady) { super.onBackPressed(); return; }
        web.evaluateJavascript("(window.__onBack?window.__onBack():'exit')", v -> {
            if (v != null && v.contains("exit")) finish();
        });
    }

    private void js(String code) {
        ui.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    // ---------------- Banner reklam ----------------
    private void setBannerUi(boolean show) {
        bannerWanted = show;
        if (!show) {
            bannerBox.setVisibility(View.GONE);
            if (banner != null) banner.pause();
            return;
        }
        if (banner == null) {
            banner = new AdView(this);
            banner.setAdUnitId(getString(R.string.admob_banner_id));
            banner.setAdSize(adaptiveSize());
            banner.setAdListener(new AdListener() {
                @Override public void onAdLoaded() { if (bannerWanted) bannerBox.setVisibility(View.VISIBLE); }
                @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { bannerBox.setVisibility(View.GONE); }
            });
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL);
            bannerBox.addView(banner, lp);
            banner.loadAd(new AdRequest.Builder().build());
        } else {
            banner.resume();
            bannerBox.setVisibility(View.VISIBLE);
        }
    }

    @SuppressWarnings("deprecation")
    private AdSize adaptiveSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        // Yatay ekranda banner'ı geniş ama ince tutmak için genişliği sınırla.
        int wDp = (int) Math.min(dm.widthPixels / dm.density, 468);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, wDp);
    }

    // ---------------- Ödüllü reklam ----------------
    private void loadRewarded() {
        if (rewarded != null || rewardedLoading) return;
        rewardedLoading = true;
        RewardedAd.load(this, getString(R.string.admob_rewarded_id), new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(@NonNull RewardedAd ad) { rewarded = ad; rewardedLoading = false; }
                    @Override public void onAdFailedToLoad(@NonNull LoadAdError e) {
                        rewarded = null; rewardedLoading = false;
                        ui.postDelayed(MainActivity.this::loadRewarded, 30000);
                    }
                });
    }

    private void showRewardedUi() {
        if (rewarded == null) {
            loadRewarded();
            js("window.__adResult&&__adResult(false)");
            return;
        }
        rewardEarned = false;
        RewardedAd ad = rewarded;
        rewarded = null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                js("window.__adResult&&__adResult(" + rewardEarned + ")");
                loadRewarded();
                hideSystemBars();
            }
            @Override public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError e) {
                js("window.__adResult&&__adResult(false)");
                loadRewarded();
            }
        });
        // Ödül SADECE reklam sonuna kadar izlenirse verilir.
        ad.show(this, item -> rewardEarned = true);
    }

    // ---------------- Google Play Faturalandırma ----------------
    private void setupBilling() {
        billing = BillingClient.newBuilder(this)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build();
        connectBilling();
    }

    private void connectBilling() {
        billing.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(@NonNull BillingResult r) {
                if (r.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryProducts();
                    checkOwned();
                }
            }
            @Override public void onBillingServiceDisconnected() {
                ui.postDelayed(() -> { if (billing != null && !billing.isReady()) connectBilling(); }, 5000);
            }
        });
    }

    private void queryProducts() {
        List<QueryProductDetailsParams.Product> list = new ArrayList<>();
        List<String> all = new ArrayList<>(CONSUMABLE);
        all.addAll(PERMANENT);
        for (String id : all) {
            list.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id).setProductType(BillingClient.ProductType.INAPP).build());
        }
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(list).build(),
                (r, details) -> {
                    if (r.getResponseCode() != BillingClient.BillingResponseCode.OK || details == null) return;
                    for (ProductDetails d : details) products.put(d.getProductId(), d);
                    pushPrices();
                });
    }

    // Play'deki gerçek yerel fiyatları mağaza ekranına yazar.
    private void pushPrices() {
        if (!pageReady) return;
        StringBuilder sb = new StringBuilder();
        for (ProductDetails d : products.values()) {
            ProductDetails.OneTimePurchaseOfferDetails o = d.getOneTimePurchaseOfferDetails();
            if (o != null) sb.append("window.__iapPrice&&__iapPrice(").append(q(d.getProductId()))
                    .append(",").append(q(o.getFormattedPrice())).append(");");
        }
        if (sb.length() > 0) js(sb.toString());
    }

    private void buyUi(String id) {
        ProductDetails d = products.get(id);
        if (billing == null || !billing.isReady() || d == null) {
            if (billing != null && !billing.isReady()) connectBilling();
            js("window.__iapResult&&__iapResult(" + q(id) + ",false,null)");
            return;
        }
        BillingFlowParams.ProductDetailsParams p = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(d).build();
        BillingResult r = billing.launchBillingFlow(this,
                BillingFlowParams.newBuilder().setProductDetailsParamsList(Arrays.asList(p)).build());
        if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            js("window.__iapResult&&__iapResult(" + q(id) + ",false,null)");
        }
    }

    private String pendingId; // satın alma ekranı açık olan ürün

    @Override
    public void onPurchasesUpdated(@NonNull BillingResult r, List<Purchase> purchases) {
        int code = r.getResponseCode();
        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase p : purchases) deliver(p);
        } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            checkOwned();
        } else if (pendingId != null) {
            js("window.__iapResult&&__iapResult(" + q(pendingId) + ",false,null)");
        }
        pendingId = null;
    }

    // Ödemesi TAMAMLANMIŞ satın almayı oyuna iletir. Oyun aynı jetonu iki kez işlemez,
    // ardından consume()/ack() çağırır. Bekleyen (PENDING) ödemelerde ödül verilmez.
    private void deliver(Purchase p) {
        if (p.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        for (String id : p.getProducts()) {
            if (PERMANENT.contains(id) && p.isAcknowledged()) {
                js("window.__iapOwned&&__iapOwned(" + q(id) + ")");
            } else {
                js("window.__iapResult&&__iapResult(" + q(id) + ",true," + q(p.getPurchaseToken()) + ")");
            }
        }
    }

    // Uygulama açılışında / geri dönüşte: kalıcı ürünleri geri yükler, yarım kalan teslimatları tamamlar.
    private void checkOwned() {
        if (billing == null || !billing.isReady() || !pageReady) return;
        billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP).build(), (r, list) -> {
            if (r.getResponseCode() != BillingClient.BillingResponseCode.OK || list == null) return;
            for (Purchase p : list) deliver(p);
        });
    }

    private void consumeToken(String token) {
        if (billing == null || !billing.isReady() || token == null) return;
        billing.consumeAsync(ConsumeParams.newBuilder().setPurchaseToken(token).build(), (r, t) -> { });
    }

    private void ackToken(String token) {
        if (billing == null || !billing.isReady() || token == null) return;
        billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(token).build(), r -> { });
    }

    // ---------------- JavaScript köprüsü ----------------
    private class Bridge {
        @JavascriptInterface public void setBanner(boolean show) { ui.post(() -> setBannerUi(show)); }
        @JavascriptInterface public void showRewarded() { ui.post(MainActivity.this::showRewardedUi); }
        @JavascriptInterface public void buy(String id) { ui.post(() -> { pendingId = id; buyUi(id); }); }
        @JavascriptInterface public void consume(String token) { ui.post(() -> consumeToken(token)); }
        @JavascriptInterface public void ack(String token) { ui.post(() -> ackToken(token)); }
        @JavascriptInterface public void restore() { ui.post(MainActivity.this::checkOwned); }
        @JavascriptInterface public boolean isApp() { return true; }
    }
}
