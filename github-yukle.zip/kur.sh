#!/bin/bash
# Düz yüklenen dosyaları Android proje yapısına yerleştirir (GitHub Actions çalıştırır).
set -e
M=app/src/main
mkdir -p $M/java/com/portalosmanli/oyun $M/assets $M/res/values
cp app-build.gradle app/build.gradle
cp index.html $M/assets/index.html
cp MainActivity.java $M/java/com/portalosmanli/oyun/MainActivity.java
cp AndroidManifest.xml $M/AndroidManifest.xml
cp strings.xml themes.xml $M/res/values/
for q in mdpi hdpi xhdpi xxhdpi xxxhdpi; do mkdir -p $M/res/mipmap-$q; cp ikon-$q.png $M/res/mipmap-$q/ic_launcher.png; done
echo "Proje hazır"
